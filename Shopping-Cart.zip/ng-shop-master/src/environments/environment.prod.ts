export const environment = {
  production: true,
  apiBase: 'https://ngshop-27da4.firebaseio.com'
};
